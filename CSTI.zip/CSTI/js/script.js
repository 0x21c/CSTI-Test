function loadCopyright() {
    const el = document.getElementById('copyright');
    if (el) {
        const year = '2026';
        const author = ['50', '49', '67'].map(c => String.fromCharCode(parseInt(c))).join('');
        const domain = ['104', '116', '116', '112', '115', '58', '47', '47', '48', '120', '50', '49', '99', '46', '99', '99'].map(c => String.fromCharCode(parseInt(c))).join('');
        el.innerHTML = '<p>© ' + year + ' ' + author + '科技 版权所有</p><p><a href="' + domain + '" target="_blank" rel="noopener noreferrer">' + domain + '</a></p>';
    }
}

document.addEventListener('DOMContentLoaded', loadCopyright);
window.addEventListener('load', loadCopyright);

const imageNames = {
    entryFragger: "entryFragger.png",
    awper: "awper.png",
    igl: "igl.png",
    support: "support.png",
    lurker: "lurker.png",
    laoliu: "laoliu.png",
    reckless: "reckless.png",
    toxic: "toxic.png",
    casual: "casual.png",
    skinCollector: "skinCollector.png",
    clutchGod: "clutchGod.png",
    tradeFragger: "tradeFragger.png",
    quitter: "quitter.png",
    silent: "silent.png",
    all: "awper.png"
};

const proPlayers = {
    donk: {
        name: "donk",
        realName: "Danil Kryshkovets",
        country: "Russia",
        team: "Cloud9",
        role: "突破手",
        achievements: ["2024 IEM Rio Major冠军", "2024 BLAST Premier全球总决赛冠军"],
        stats: { rating: 1.28, kdRatio: 1.35, headshotPercent: 52 }
    },
    kennys: {
        name: "kennyS",
        realName: "Kenny Schrub",
        country: "France",
        team: "G2 Esports",
        role: "狙击手",
        achievements: ["2015 ESL One Cologne冠军", "2016 MLG Columbus冠军"],
        stats: { rating: 1.22, kdRatio: 1.28, headshotPercent: 58 }
    },
    apex: {
        name: "apEX",
        realName: "Dan Madesclaire",
        country: "France",
        team: "Team Vitality",
        role: "IGL",
        achievements: ["2023 Paris Major冠军", "2024 IEM Katowice冠军"],
        stats: { rating: 1.08, kdRatio: 1.05, headshotPercent: 41 }
    },
    magisk: {
        name: "Magisk",
        realName: "Emil Reif",
        country: "Denmark",
        team: "Astralis",
        role: "支援手",
        achievements: ["2019 IEM Katowice冠军", "2019 StarLadder Major冠军"],
        stats: { rating: 1.12, kdRatio: 1.15, headshotPercent: 45 }
    },
    spinx: {
        name: "Spinx",
        realName: "Daniel Blady",
        country: "Israel",
        team: "Team Vitality",
        role: "潜伏者",
        achievements: ["2024 BLAST Premier春季总决赛冠军", "2024 ESL Pro League冠军"],
        stats: { rating: 1.18, kdRatio: 1.22, headshotPercent: 48 }
    },
    blitz: {
        name: "bLitz",
        realName: "Nikolay Bogdanov",
        country: "Russia",
        team: "Cloud9",
        role: "自由人",
        achievements: ["2024 IEM Rio Major冠军"],
        stats: { rating: 1.15, kdRatio: 1.18, headshotPercent: 46 }
    },
    m0nesy: {
        name: "m0NESY",
        realName: "Ilya Osipov",
        country: "Russia",
        team: "G2 Esports",
        role: "步枪手",
        achievements: ["2023 BLAST Premier全球总决赛冠军", "2024 IEM Katowice亚军"],
        stats: { rating: 1.35, kdRatio: 1.42, headshotPercent: 55 }
    },
    flamez: {
        name: "flameZ",
        realName: "Nikola Shevchenko",
        country: "Israel",
        team: "Cloud9",
        role: "步枪手",
        achievements: ["2024 IEM Rio Major冠军"],
        stats: { rating: 1.20, kdRatio: 1.25, headshotPercent: 49 }
    },
    sh1ro: {
        name: "sh1ro",
        realName: "Dmitry Sokolov",
        country: "Russia",
        team: "Cloud9",
        role: "狙击手",
        achievements: ["2024 IEM Rio Major冠军", "2023 BLAST Premier秋季总决赛冠军"],
        stats: { rating: 1.28, kdRatio: 1.32, headshotPercent: 54 }
    },
    brollan: {
        name: "Brollan",
        realName: "Ludvig Brolin",
        country: "Sweden",
        team: "Fnatic",
        role: "步枪手",
        achievements: ["2023 BLAST Premier春季总决赛冠军"],
        stats: { rating: 1.15, kdRatio: 1.18, headshotPercent: 47 }
    },
    ropz: {
        name: "ropz",
        realName: "Robin Kool",
        country: "Estonia",
        team: "FaZe Clan",
        role: "步枪手",
        achievements: ["2022 PGL Major Antwerp冠军", "2023 IEM Rio冠军"],
        stats: { rating: 1.25, kdRatio: 1.30, headshotPercent: 51 }
    },
    magixx: {
        name: "magixx",
        realName: "Ivan Meshcheryakov",
        country: "Russia",
        team: "Team Spirit",
        role: "步枪手",
        achievements: ["2024 IEM Katowice冠军"],
        stats: { rating: 1.18, kdRatio: 1.22, headshotPercent: 48 }
    },
    jimpphat: {
        name: "Jimpphat",
        realName: "Joosep Jõgi",
        country: "Estonia",
        team: "ENCE",
        role: "步枪手",
        achievements: ["2022 IEM Rio亚军"],
        stats: { rating: 1.10, kdRatio: 1.12, headshotPercent: 44 }
    },
    teses: {
        name: "TeSeS",
        realName: "Thomas Roslyng",
        country: "Denmark",
        team: "Astralis",
        role: "步枪手",
        achievements: ["2024 BLAST Premier春季总决赛亚军"],
        stats: { rating: 1.12, kdRatio: 1.15, headshotPercent: 46 }
    },
    niko: {
        name: "NiKo",
        realName: "Nikola Kovač",
        country: "Bosnia and Herzegovina",
        team: "G2 Esports",
        role: "全能选手",
        achievements: ["2016 MLG Columbus冠军", "2023 BLAST Premier全球总决赛冠军"],
        stats: { rating: 1.26, kdRatio: 1.29, headshotPercent: 53 }
    }
};

const types = {
    entryFragger: {
        name: { zh: "突破手", en: "Entry Fragger", zh_tw: "突破手" },
        desc: {
            zh: "🔥 突破手人格\n你是团队的开路先锋，敢于直面敌人！\n核心特质：\n• 冲锋在前，永不退缩\n• 喜欢刚枪，枪法精准\n• 残局处理能力强\n游戏风格：\n• 开局rush B\n• 单人突破防线\n• 为团队创造机会",
            en: "🔥 Entry Fragger\nYou are the team's vanguard, always charging forward!\nCore Traits:\n• Fearless, never backs down\n• Aggressive playstyle\n• Strong aim and mechanics\nPlaystyle:\n• Early game rushes\n• Solo pushes\n• Creating space for teammates",
            zh_tw: "🔥 突破手\n你是團隊的開路先鋒，敢於直面敵人！\n核心特質：\n• 衝鋒在前，永不退縮\n• 喜歡剛槍，槍法精準\n• 殘局處理能力強\n遊戲風格：\n• 開局rush B\n• 單人突破防線\n• 為團隊創造機會"
        },
        player: "donk",
        playerDesc: { zh: "像donk一样，你拥有出色的突破能力", en: "Like donk, you have exceptional entry fragging ability", zh_tw: "像donk一樣，你擁有出色的突破能力" }
    },
    awper: {
        name: { zh: "狙击手", en: "AWPer", zh_tw: "狙擊手" },
        desc: {
            zh: "🎯 狙击手人格\n你是战场上的幽灵，一枪制敌！\n核心特质：\n• 冷静沉着，耐心等待\n• 精准的狙击技术\n• 善于寻找最佳位置\n游戏风格：\n• 远程压制\n• 守株待兔\n• 关键时刻一击致命",
            en: "🎯 AWPer\nYou are the ghost on the battlefield, one shot one kill!\nCore Traits:\n• Calm and patient\n• Precise aim\n• Excellent positioning\nPlaystyle:\n• Long-range control\n• Ambush tactics\n• Game-changing shots",
            zh_tw: "🎯 狙擊手\n你是戰場上的幽靈，一槍制敵！\n核心特質：\n• 冷靜沉著，耐心等待\n• 精準的狙擊技術\n• 善於尋找最佳位置\n遊戲風格：\n• 遠程壓制\n• 守株待兔\n• 關鍵時刻一擊致命"
        },
        player: "kennys",
        playerDesc: { zh: "像kennys一样，你是致命的狙击手", en: "Like kennys, you are a deadly sniper", zh_tw: "像kennys一樣，你是致命的狙擊手" }
    },
    igl: {
        name: { zh: "战术大师", en: "IGL", zh_tw: "戰術大師" },
        desc: {
            zh: "🧠 战术大师人格\n你是团队的大脑，指挥若定！\n核心特质：\n• 全局意识强\n• 善于分析局势\n• 决策果断\n游戏风格：\n• 制定战术策略\n• 指挥团队行动\n• 掌控比赛节奏",
            en: "🧠 IGL (In-Game Leader)\nYou are the team's brain, calling the shots!\nCore Traits:\n• Great game sense\n• Strategic thinking\n• Decisive leader\nPlaystyle:\n• Tactical planning\n• Team coordination\n• Game tempo control",
            zh_tw: "🧠 戰術大師\n你是團隊的大腦，指揮若定！\n核心特質：\n• 全局意識強\n• 善於分析局勢\n• 決策果斷\n遊戲風格：\n• 制定戰術策略\n• 指揮團隊行動\n• 掌控比賽節奏"
        },
        player: "apEX",
        playerDesc: { zh: "像apEX一样，你是天生的领导者", en: "Like apEX, you are a natural leader", zh_tw: "像apEX一樣，你是天生的領導者" }
    },
    support: {
        name: { zh: "支援手", en: "Support", zh_tw: "支援手" },
        desc: {
            zh: "🛡️ 支援手人格\n你是团队的守护者，默默奉献！\n核心特质：\n• 团队意识强\n• 乐于牺牲自己\n• 善于辅助队友\n游戏风格：\n• 提供火力支援\n• 清理后路\n• 保护队友安全",
            en: "🛡️ Support\nYou are the team's guardian, always helping others!\nCore Traits:\n• Team-oriented\n• Selfless play\n• Great utility usage\nPlaystyle:\n• Fire support\n• Area denial\n• Protecting teammates",
            zh_tw: "🛡️ 支援手\n你是團隊的守護者，默默奉獻！\n核心特質：\n• 團隊意識強\n• 樂於犧牲自己\n• 善於輔助隊友\n遊戲風格：\n• 提供火力支援\n• 清理後路\n• 保護隊友安全"
        },
        player: "Magisk",
        playerDesc: { zh: "像Magisk一样，你是可靠的团队支柱", en: "Like Magisk, you are a reliable team player", zh_tw: "像Magisk一樣，你是可靠的團隊支柱" }
    },
    lurker: {
        name: { zh: "潜伏者", en: "Lurker", zh_tw: "潛伏者" },
        desc: {
            zh: "🐱 潜伏者人格\n你是暗处的猎手，出其不意！\n核心特质：\n• 耐心十足\n• 善于伪装\n• 把握时机\n游戏风格：\n• 单独行动\n• 寻找背身\n• 收割残局",
            en: "🐱 Lurker\nYou are the hunter in the shadows, striking when least expected!\nCore Traits:\n• Extremely patient\n• Sneaky playstyle\n• Timing is everything\nPlaystyle:\n• Solo flanking\n• Backstabbing\n• Cleanup duty",
            zh_tw: "🐱 潛伏者\n你是暗處的獵手，出其不意！\n核心特質：\n• 耐心十足\n• 善於偽裝\n• 把握時機\n遊戲風格：\n• 單獨行動\n• 尋找背身\n• 收割殘局"
        },
        player: "Spinx",
        playerDesc: { zh: "像Spinx一样，你是致命的潜伏者", en: "Like Spinx, you are a deadly lurker", zh_tw: "像Spinx一樣，你是致命的潛伏者" }
    },
    laoliu: {
        name: { zh: "老六", en: "Camper", zh_tw: "老六" },
        desc: {
            zh: "🤫 老六人格\n你是战术大师，擅长阴人！\n核心特质：\n• 耐心极佳\n• 善于伪装\n• 出其不意\n游戏风格：\n• 卡点阴人\n• 守株待兔\n• 让人心态爆炸",
            en: "🤫 Camper\nYou are the master of ambush, catching enemies off guard!\nCore Traits:\n• Exceptionally patient\n• Great at hiding\n• Unpredictable\nPlaystyle:\n• Ambush tactics\n• Holding angles\n• Psychological warfare",
            zh_tw: "🤫 老六\n你是戰術大師，擅長陰人！\n核心特質：\n• 耐心極佳\n• 善於偽裝\n• 出其不意\n遊戲風格：\n• 卡點陰人\n• 守株待兔\n• 讓人心態爆炸"
        },
        player: "bLitz",
        playerDesc: { zh: "像bLitz一样，你擅长卡点阴人", en: "Like bLitz, you excel at holding angles", zh_tw: "像bLitz一樣，你擅長卡點陰人" }
    },
    reckless: {
        name: { zh: "莽夫", en: "Reckless", zh_tw: "莽夫" },
        desc: {
            zh: "💀 莽夫人格\n你是无畏的战士，勇往直前！\n核心特质：\n• 无所畏惧\n• 勇猛冲锋\n• 不怕牺牲\n游戏风格：\n• 无脑冲锋\n• 人数优势？不存在的\n• 用生命换击杀",
            en: "💀 Reckless\nYou are the fearless warrior, always charging in!\nCore Traits:\n• No fear\n• Aggressive pushes\n• Death or glory\nPlaystyle:\n• Head-on engagements\n• Outnumbered? No problem\n• Trading life for kills",
            zh_tw: "💀 莽夫\n你是無畏的戰士，勇往直前！\n核心特質：\n• 無所畏懼\n• 勇猛衝鋒\n• 不怕犧牲\n遊戲風格：\n• 無腦衝鋒\n• 人數優勢？不存在的\n• 用生命換擊殺"
        },
        player: "m0NESY",
        playerDesc: { zh: "像m0NESY一样，你拥有超强的个人能力", en: "Like m0NESY, you have incredible individual skill", zh_tw: "像m0NESY一樣，你擁有超強的個人能力" }
    },
    toxic: {
        name: { zh: "毒瘤", en: "Toxic", zh_tw: "毒瘤" },
        desc: {
            zh: "💢 毒瘤人格\n你是团队的催化剂，激情四射！\n核心特质：\n• 情绪激动\n• 爱指挥队友\n• 压力大时容易失控\n游戏风格：\n• 语音指挥\n• 喷子模式\n• 赢了吹输了甩锅",
            en: "💢 Toxic\nYou are the team's spark, full of passion!\nCore Traits:\n• Emotional\n• Vocal leader\n• High strung under pressure\nPlaystyle:\n• Constant callouts\n• Aggressive comms\n• Win or whine",
            zh_tw: "💢 毒瘤\n你是團隊的催化劑，激情四射！\n核心特質：\n• 情緒激動\n• 愛指揮隊友\n• 壓力大時容易失控\n遊戲風格：\n• 語音指揮\n• 噴子模式\n• 贏了吹輸了甩鍋"
        },
        player: "flameZ",
        playerDesc: { zh: "像flameZ一样，你充满激情和斗志", en: "Like flameZ, you are full of passion and drive", zh_tw: "像flameZ一樣，你充滿激情和斗志" }
    },
    casual: {
        name: { zh: "休闲玩家", en: "Casual", zh_tw: "休閒玩家" },
        desc: {
            zh: "😌 休闲玩家人格\n你玩游戏只为娱乐，享受过程！\n核心特质：\n• 心态平和\n• 输赢无所谓\n• 重在参与\n游戏风格：\n• 娱乐至上\n• 聊天为主\n• 快乐就好",
            en: "😌 Casual Player\nYou play for fun, enjoying the journey!\nCore Traits:\n• Laid back\n• Winning isn't everything\n• Participation matters\nPlaystyle:\n• Fun over competition\n• Social gaming\n• Just having a good time",
            zh_tw: "😌 休閒玩家\n你玩遊戲只為娛樂，享受過程！\n核心特質：\n• 心態平和\n• 輸贏無所謂\n• 重在參與\n遊戲風格：\n• 娛樂至上\n• 聊天為主\n• 快樂就好"
        },
        player: "sh1ro",
        playerDesc: { zh: "像sh1ro一样，你享受游戏的乐趣", en: "Like sh1ro, you enjoy the game", zh_tw: "像sh1ro一樣，你享受遊戲的樂趣" }
    },
    skinCollector: {
        name: { zh: "皮肤收藏家", en: "Skin Collector", zh_tw: "皮膚收藏家" },
        desc: {
            zh: "💎 皮肤收藏家人格\n你是游戏的时尚达人，颜值即正义！\n核心特质：\n• 注重外观\n• 追求稀有物品\n• 审美独特\n游戏风格：\n• 皮肤展示\n• 装备搭配\n• 游戏第二，颜值第一",
            en: "💎 Skin Collector\nYou are the fashionista of the game, style is everything!\nCore Traits:\n• Appearance matters\n• Rare item hunter\n• Unique taste\nPlaystyle:\n• Skin showcase\n• Loadout aesthetics\n• Style over substance",
            zh_tw: "💎 皮膚收藏家\n你是遊戲的時尚達人，顏值即正義！\n核心特質：\n• 注重外觀\n• 追求稀有物品\n• 審美獨特\n遊戲風格：\n• 皮膚展示\n• 裝備搭配\n• 遊戲第二，顏值第一"
        },
        player: "Brollan",
        playerDesc: { zh: "像Brollan一样，你对皮肤有独特的鉴赏力", en: "Like Brollan, you have great taste in skins", zh_tw: "像Brollan一樣，你對皮膚有獨特的鑑賞力" }
    },
    clutchGod: {
        name: { zh: "残局大师", en: "Clutch God", zh_tw: "殘局大師" },
        desc: {
            zh: "⚡ 残局大师人格\n你是绝境中的希望，力挽狂澜！\n核心特质：\n• 心理素质强\n• 冷静处理残局\n• 关键时刻不掉链子\n游戏风格：\n• 1vN不在话下\n• 压力越大越强\n• 绝境翻盘",
            en: "⚡ Clutch God\nYou are the hero in desperate situations, turning the tide!\nCore Traits:\n• Strong mental game\n• Cool under pressure\n• Delivers when it matters\nPlaystyle:\n• 1vN specialist\n• Thrives under pressure\n• Impossible comebacks",
            zh_tw: "⚡ 殘局大師\n你是絕境中的希望，力挽狂瀾！\n核心特質：\n• 心理素質強\n• 冷靜處理殘局\n• 關鍵時刻不掉鏈子\n遊戲風格：\n• 1vN不在話下\n• 壓力越大越強\n• 絕境翻盤"
        },
        player: "ropz",
        playerDesc: { zh: "像ropz一样，你是残局处理专家", en: "Like ropz, you are a clutch specialist", zh_tw: "像ropz一樣，你是殘局處理專家" }
    },
    tradeFragger: {
        name: { zh: "互换王", en: "Trade Fragger", zh_tw: "互換王" },
        desc: {
            zh: "⚔️ 互换王人格\n你是团队的基石，稳如泰山！\n核心特质：\n• 稳健可靠\n• 注重效率\n• 善于互换\n游戏风格：\n• 与敌人一换一\n• 保证团队优势\n• 稳定输出",
            en: "⚔️ Trade Fragger\nYou are the team's rock, steady and reliable!\nCore Traits:\n• Consistent\n• Efficient\n• Great at trading\nPlaystyle:\n• Equal exchanges\n• Maintain team advantage\n• Steady output",
            zh_tw: "⚔️ 互換王\n你是團隊的基石，穩如泰山！\n核心特質：\n• 穩健可靠\n• 注重效率\n• 善於互換\n遊戲風格：\n• 與敵人一換一\n• 保證團隊優勢\n• 穩定輸出"
        },
        player: "magixx",
        playerDesc: { zh: "像magixx一样，你是团队的稳定器", en: "Like magixx, you are the team's stabilizer", zh_tw: "像magixx一樣，你是團隊的穩定器" }
    },
    quitter: {
        name: { zh: "摆烂哥", en: "Quitter", zh_tw: "擺爛哥" },
        desc: {
            zh: "😴 摆烂哥人格\n你是逆风局的终结者，一落后就GG！\n核心特质：\n• 心态容易爆炸\n• 缺乏耐心\n• 容易放弃\n游戏风格：\n• 比分落后=游戏结束\n• GG下一把张口就来\n• 队友鼓励？那是耳旁风",
            en: "😴 Quitter\nYou are the surrender specialist, giving up when behind!\nCore Traits:\n• Fragile mental\n• Impatient\n• Quick to give up\nPlaystyle:\n• Behind = game over\n• 'GG next' is your catchphrase\n• Team morale doesn't matter",
            zh_tw: "😴 擺爛哥\n你是逆風局的終結者，一落後就GG！\n核心特質：\n• 心態容易爆炸\n• 缺乏耐心\n• 容易放棄\n遊戲風格：\n• 比分落後=遊戲結束\n• GG下一張口就來\n• 隊友鼓勵？那是耳旁風"
        },
        player: "Jimpphat",
        playerDesc: { zh: "每个人都有状态不好的时候，调整心态再来！", en: "Everyone has off days, just keep trying!", zh_tw: "每個人都有狀態不好的時候，調整心態再來！" }
    },
    silent: {
        name: { zh: "沉默者", en: "Silent", zh_tw: "沉默者" },
        desc: {
            zh: "🤫 沉默者人格\n你是团队的独行侠，默默Carry！\n核心特质：\n• 不喜交流\n• 专注游戏\n• 用实力说话\n游戏风格：\n• 少说话多做事\n• 默默发育\n• 用战绩证明自己",
            en: "🤫 Silent Player\nYou are the team's lone wolf, letting actions speak!\nCore Traits:\n• Minimal communication\n• Focused\n• Actions over words\nPlaystyle:\n• Lead by example\n• Silent but deadly\n• Let your stats do the talking",
            zh_tw: "🤫 沉默者\n你是團隊的獨行俠，默默Carry！\n核心特質：\n• 不喜交流\n• 專注遊戲\n• 用實力說話\n遊戲風格：\n• 少說話多做事\n• 默默發育\n• 用戰績證明自己"
        },
        player: "TeSeS",
        playerDesc: { zh: "像TeSeS一样，你用实力说话", en: "Like TeSeS, you let your gameplay speak", zh_tw: "像TeSeS一樣，你用實力說話" }
    },
    all: {
        name: { zh: "全能选手", en: "All-Rounder", zh_tw: "全能選手" },
        desc: {
            zh: "🌟 全能选手人格\n你是团队的万金油，样样精通！\n核心特质：\n• 适应性强\n• 多才多艺\n• 灵活多变\n游戏风格：\n• 能打任何位置\n• 战术灵活\n• 团队粘合剂",
            en: "🌟 All-Rounder\nYou are the team's versatile player, good at everything!\nCore Traits:\n• Adaptable\n• Versatile\n• Flexible\nPlaystyle:\n• Any role, any situation\n• Tactical flexibility\n• Team glue",
            zh_tw: "🌟 全能選手\n你是團隊的萬金油，樣樣精通！\n核心特質：\n• 適應性強\n• 多才多藝\n• 靈活多變\n遊戲風格：\n• 能打任何位置\n• 戰術靈活\n• 團隊粘合劑"
        },
        player: "niko",
        playerDesc: { zh: "像niko一样，你是全能选手", en: "Like niko, you are an all-rounder", zh_tw: "像niko一樣，你是全能選手" }
    }
};

const lang = {
    zh: {
        title: "CSTI游戏人格测试",
        subtitle: "探索你的CS2游戏人格",
        description: "通过35道题目，发现你的游戏风格和职业选手相似度",
        feature1: "15种游戏人格",
        feature2: "职业选手匹配",
        feature3: "段位预估",
        startBtn: "开始测试",
        quizTitle: "CSTI游戏人格测试",
        progressText: "已完成 <span id='answered'>0</span> / <span id='total'>35</span> 题",
        submitBtn: "查看结果",
        viewResult: "查看结果",
        match: "匹配度",
        speed: "答题速度",
        rank: "段位预估",
        personality: "人格解读",
        dimensionsTitle: "十五维人格评分",
        proMatch: "职业玩家匹配",
        encouragement: "鼓励语",
        restartBtn: "重新测试",
        shareBtn: "分享结果",
        homeBtn: "返回主页",
        shareTitle: "分享CSTI测评成绩",
        scanText: "扫码测试",
        copyLinkText: "复制测试链接",
        copySuccess: "复制成功！",
        options: ["非常不符合", "不太符合", "一般", "比较符合", "非常符合"],
        ranks: ["D", "D+", "C", "C+", "B", "B+", "A", "A+", "S", "黄金S", "钻石S", "魔王S"],
        encouragementText: {
            entryFragger: "继续保持你的冲劲，你就是团队的希望！",
            awper: "冷静的头脑是胜利的关键，继续练习你的狙击技巧！",
            igl: "出色的指挥能力是团队获胜的关键，相信你的判断！",
            support: "团队的胜利离不开你的奉献，继续加油！",
            lurker: "耐心是你的武器，潜伏等待最佳时机！",
            laoliu: "战术大师！你的阴人技巧让敌人闻风丧胆！",
            reckless: "勇猛无畏是你的标签，但也要注意团队配合！",
            toxic: "激情是好事，但要学会控制情绪，成为真正的领袖！",
            casual: "享受游戏最重要，开心就好！",
            skinCollector: "颜值即正义，继续收集更多炫酷皮肤！",
            clutchGod: "残局处理大师！你的心理素质无人能敌！",
            tradeFragger: "稳健可靠是你的代名词，团队需要你！",
            quitter: "心态很重要，不要轻易放弃，坚持就是胜利！",
            silent: "沉默是金，用实力说话，你是真正的强者！",
            all: "全能选手！你的能力让人惊叹，继续保持！"
        },
        intro: {
            personality: "👤 15种游戏人格",
            proplayers: "⭐ 职业选手匹配",
            ranks: "🏆 段位预估",
            rank_s: "魔王段位"
        },
        personalities: {
            entryFragger: "突破手",
            sniper: "狙击手",
            tactician: "战术大师",
            support: "支援手",
            lurker: "潜伏者",
            camper: "老六",
            rusher: "莽夫",
            toxic: "毒瘤",
            casual: "休闲玩家",
            collector: "皮肤收藏家",
            clutch: "残局大师",
            trader: "互换王",
            giveup: "摆烂哥",
            silent: "沉默者",
            allround: "全能选手"
        }
    },
    en: {
        title: "CSTI Game Personality Test",
        subtitle: "Discover your CS2 Game Personality",
        description: "Answer 35 questions to find your playstyle and pro player similarity",
        feature1: "15 Game Personalities",
        feature2: "Pro Player Match",
        feature3: "Rank Estimation",
        startBtn: "Start Test",
        quizTitle: "CSTI Game Personality Test",
        progressText: "<span id='answered'>0</span> / <span id='total'>35</span> completed",
        submitBtn: "View Result",
        viewResult: "View Result",
        match: "Match",
        speed: "Speed",
        rank: "Estimated Rank",
        personality: "Personality Analysis",
        dimensionsTitle: "15-Dimension Personality Score",
        proMatch: "Pro Player Match",
        encouragement: "Encouragement",
        restartBtn: "Take Again",
        shareBtn: "Share Result",
        homeBtn: "Back to Home",
        shareTitle: "Share Your Result",
        scanText: "Scan to Test",
        copyLinkText: "Copy Link",
        copySuccess: "Copied!",
        options: ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"],
        ranks: ["D", "D+", "C", "C+", "B", "B+", "A", "A+", "S", "Gold S", "Diamond S", "Demon S"],
        encouragementText: {
            entryFragger: "Keep your aggression! You're the team's vanguard!",
            awper: "Stay calm and keep practicing your aim!",
            igl: "Great leadership! Trust your decisions!",
            support: "Teamwork makes the dream work! Keep supporting!",
            lurker: "Patience is your weapon! Wait for the perfect moment!",
            laoliu: "Master of ambushes! Your tactics are deadly!",
            reckless: "Fearless warrior! Just remember team coordination!",
            toxic: "Passion is good, but control your emotions!",
            casual: "Enjoy the game! That's what matters most!",
            skinCollector: "Style is everything! Keep collecting!",
            clutchGod: "Clutch specialist! Your mental game is strong!",
            tradeFragger: "Consistent and reliable! Team needs you!",
            quitter: "Stay positive! Never give up!",
            silent: "Actions speak louder than words! Keep grinding!",
            all: "Versatile player! Your skills are amazing!"
        },
        intro: {
            personality: "👤 15 Game Personalities",
            proplayers: "⭐ Pro Player Match",
            ranks: "🏆 Rank Estimation",
            rank_s: "Demon Rank"
        },
        personalities: {
            entryFragger: "Entry Fragger",
            sniper: "AWPer",
            tactician: "IGL",
            support: "Support",
            lurker: "Lurker",
            camper: "Camper",
            rusher: "Rusher",
            toxic: "Toxic",
            casual: "Casual",
            collector: "Skin Collector",
            clutch: "Clutch Master",
            trader: "Trade Fragger",
            giveup: "Quitter",
            silent: "Silent",
            allround: "All-Rounder"
        }
    },
    zh_tw: {
        title: "CSTI遊戲人格測試",
        subtitle: "探索你的CS2遊戲人格",
        description: "透過35道題目，發現你的遊戲風格和職業選手相似度",
        feature1: "15種遊戲人格",
        feature2: "職業選手匹配",
        feature3: "段位預估",
        startBtn: "開始測試",
        quizTitle: "CSTI遊戲人格測試",
        progressText: "已完成 <span id='answered'>0</span> / <span id='total'>35</span> 題",
        submitBtn: "查看結果",
        viewResult: "查看結果",
        match: "匹配度",
        speed: "答題速度",
        rank: "段位預估",
        personality: "人格解讀",
        dimensionsTitle: "十五維人格評分",
        proMatch: "職業玩家匹配",
        encouragement: "鼓勵語",
        restartBtn: "重新測試",
        shareBtn: "分享結果",
        homeBtn: "返回主頁",
        shareTitle: "分享測評成績",
        scanText: "掃碼測試",
        copyLinkText: "複製測試鏈接",
        copySuccess: "複製成功！",
        options: ["非常不符合", "不太符合", "一般", "比較符合", "非常符合"],
        ranks: ["D", "D+", "C", "C+", "B", "B+", "A", "A+", "S", "黃金S", "鑽石S", "魔王S"],
        encouragementText: {
            entryFragger: "繼續保持你的衝勁，你就是團隊的希望！",
            awper: "冷靜的頭腦是勝利的關鍵，繼續練習你的狙擊技巧！",
            igl: "出色的指揮能力是團隊獲勝的關鍵，相信你的判斷！",
            support: "團隊的勝利離不開你的奉獻，繼續加油！",
            lurker: "耐心是你的武器，潛伏等待最佳時機！",
            laoliu: "戰術大師！你的陰人技巧讓敵人聞風喪膽！",
            reckless: "勇猛無畏是你的標籤，但也要注意團隊配合！",
            toxic: "激情是好事，但要學會控制情緒，成為真正的領袖！",
            casual: "享受遊戲最重要，開心就好！",
            skinCollector: "顏值即正義，繼續收集更多炫酷皮膚！",
            clutchGod: "殘局處理大師！你的心理素質無人能敵！",
            tradeFragger: "穩健可靠是你的代名詞，團隊需要你！",
            quitter: "心態很重要，不要輕易放棄，堅持就是勝利！",
            silent: "沉默是金，用實力說話，你是真正的強者！",
            all: "全能選手！你的能力讓人驚歎，繼續保持！"
        },
        intro: {
            personality: "👤 15種遊戲人格",
            proplayers: "⭐ 職業選手匹配",
            ranks: "🏆 段位預估",
            rank_s: "魔王段位"
        },
        personalities: {
            entryFragger: "突破手",
            sniper: "狙擊手",
            tactician: "戰術大師",
            support: "支援手",
            lurker: "潛伏者",
            camper: "老六",
            rusher: "莽夫",
            toxic: "毒瘤",
            casual: "休閒玩家",
            collector: "皮膚收藏家",
            clutch: "殘局大師",
            trader: "互換王",
            giveup: "擺爛哥",
            silent: "沈默者",
            allround: "全能選手"
        }
    }
};

const questions = [
    {
        type: "entryFragger",
        text: {
            zh: "开局时，我喜欢第一个冲进敌方区域",
            en: "I like to be the first one to push into enemy territory",
            zh_tw: "開局時，我喜歡第一個衝進敵方區域"
        }
    },
    {
        type: "entryFragger",
        text: {
            zh: "即使人数处于劣势，我也会主动发起进攻",
            en: "I'll initiate fights even when outnumbered",
            zh_tw: "即使人數處於劣勢，我也會主動發起進攻"
        }
    },
    {
        type: "entryFragger",
        text: {
            zh: "我擅长使用步枪进行近距离交火",
            en: "I'm good at close-range rifle fights",
            zh_tw: "我擅長使用步槍進行近距離交火"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我更喜欢使用AWP进行远距离狙击",
            en: "I prefer using AWP for long-range sniping",
            zh_tw: "我更喜歡使用AWP進行遠距離狙擊"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我能耐心等待最佳射击时机",
            en: "I can patiently wait for the perfect shot",
            zh_tw: "我能耐心等待最佳射擊時機"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我擅长在关键位置卡点防守",
            en: "I'm good at holding angles defensively",
            zh_tw: "我擅長在關鍵位置卡點防守"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我经常指挥队友执行战术",
            en: "I often call strategies for my team",
            zh_tw: "我經常指揮隊友執行戰術"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我会根据局势灵活调整战术",
            en: "I adapt strategies based on the situation",
            zh_tw: "我會根據局勢靈活調整戰術"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我善于分析敌方的战术意图",
            en: "I'm good at reading enemy tactics",
            zh_tw: "我善於分析敵方的戰術意圖"
        }
    },
    {
        type: "support",
        text: {
            zh: "我愿意为队友提供火力支援",
            en: "I'm willing to provide fire support for teammates",
            zh_tw: "我願意為隊友提供火力支援"
        }
    },
    {
        type: "support",
        text: {
            zh: "我擅长使用道具为团队创造优势",
            en: "I'm good at using utilities to create advantages",
            zh_tw: "我擅長使用道具為團隊創造優勢"
        }
    },
    {
        type: "support",
        text: {
            zh: "保护队友是我的首要任务",
            en: "Protecting teammates is my priority",
            zh_tw: "保護隊友是我的首要任務"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "我喜欢单独行动，寻找机会偷袭敌人",
            en: "I prefer solo play, looking for flanking opportunities",
            zh_tw: "我喜歡單獨行動，尋找機會偷襲敵人"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "我善于隐藏自己的位置",
            en: "I'm good at staying hidden",
            zh_tw: "我善於隱藏自己的位置"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "残局时我能发挥最大作用",
            en: "I perform best in 1vX situations",
            zh_tw: "殘局時我能發揮最大作用"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "我喜欢在角落埋伏等待敌人",
            en: "I enjoy camping in corners waiting for enemies",
            zh_tw: "我喜歡在角落埋伏等待敵人"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "我会利用地图优势卡点阴人",
            en: "I use map advantages to ambush enemies",
            zh_tw: "我會利用地圖優勢卡點陰人"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "耐心是我的优点，我能等很久",
            en: "Patience is my strong suit, I can wait a long time",
            zh_tw: "耐心是我的優點，我能等很久"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "我喜欢无脑冲锋，不怕牺牲",
            en: "I like rushing in without fear",
            zh_tw: "我喜歡無腦衝鋒，不怕犧牲"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "我相信个人能力可以战胜一切",
            en: "I believe individual skill can overcome anything",
            zh_tw: "我相信個人能力可以戰勝一切"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "即使队友阵亡，我也会继续推进",
            en: "I keep pushing even when teammates die",
            zh_tw: "即使隊友陣亡，我也會繼續推進"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "我喜欢在语音里指挥和交流",
            en: "I like to call out and communicate aggressively",
            zh_tw: "我喜歡在語音裡指揮和交流"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "输了比赛我会感到很沮丧",
            en: "I get frustrated when losing",
            zh_tw: "輸了比賽我會感到很沮喪"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "我对队友的表现有较高要求",
            en: "I have high expectations for teammates",
            zh_tw: "我對隊友的表現有較高要求"
        }
    },
    {
        type: "casual",
        text: {
            zh: "输赢对我来说不是最重要的",
            en: "Winning isn't the most important thing to me",
            zh_tw: "輸贏對我來說不是最重要的"
        }
    },
    {
        type: "casual",
        text: {
            zh: "我喜欢和队友聊天交流",
            en: "I enjoy chatting with teammates",
            zh_tw: "我喜歡和隊友聊天交流"
        }
    },
    {
        type: "casual",
        text: {
            zh: "游戏只是我的娱乐方式",
            en: "Gaming is just for fun for me",
            zh_tw: "遊戲只是我的娛樂方式"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我很在意武器皮肤的外观",
            en: "I care about weapon skin aesthetics",
            zh_tw: "我很在意武器皮膚的外觀"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我收集了很多稀有皮肤",
            en: "I have a collection of rare skins",
            zh_tw: "我收集了很多稀有皮膚"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我会根据皮肤选择使用的武器",
            en: "I choose weapons based on their skins",
            zh_tw: "我會根據皮膚選擇使用的武器"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "面对残局，我能保持冷静",
            en: "I stay calm in clutch situations",
            zh_tw: "面對殘局，我能保持冷靜"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "我擅长处理1vN的情况",
            en: "I'm good at 1vN situations",
            zh_tw: "我擅長處理1vN的情況"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "压力越大，我的发挥越好",
            en: "I perform better under pressure",
            zh_tw: "壓力越大，我的發揮越好"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我擅长与敌人进行互换",
            en: "I'm good at trading kills",
            zh_tw: "我擅長與敵人進行互換"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我总是确保自己的死亡有价值",
            en: "I always make sure my death counts",
            zh_tw: "我總是確保自己的死亡有價值"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我注重团队整体的击杀效率",
            en: "I focus on team kill efficiency",
            zh_tw: "我注重團隊整體的擊殺效率"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "如果比分落后太多，我会想早点结束",
            en: "If we're too far behind, I want to surrender",
            zh_tw: "如果比分落後太多，我會想早點結束"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "逆风局会影响我的心态",
            en: "Losing streaks affect my mood",
            zh_tw: "逆風局會影響我的心態"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "我不太能接受连败",
            en: "I don't handle losing streaks well",
            zh_tw: "我不太能接受連敗"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我更喜欢专注游戏，少说话",
            en: "I prefer focusing on the game and staying quiet",
            zh_tw: "我更喜歡專注遊戲，少說話"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我相信用实力说话",
            en: "I believe actions speak louder than words",
            zh_tw: "我相信用實力說話"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我很少在语音里说话",
            en: "I rarely talk in voice chat",
            zh_tw: "我很少在語音裡說話"
        }
    },
    {
        type: "all",
        text: {
            zh: "我能适应各种游戏角色",
            en: "I can adapt to any role",
            zh_tw: "我能適應各種遊戲角色"
        }
    },
    {
        type: "all",
        text: {
            zh: "我擅长多种武器和战术",
            en: "I'm good with various weapons and tactics",
            zh_tw: "我擅長多種武器和戰術"
        }
    },
    {
        type: "all",
        text: {
            zh: "我可以根据团队需要改变风格",
            en: "I can change my playstyle based on team needs",
            zh_tw: "我可以根據團隊需要改變風格"
        }
    }
];

const QUESTIONS_COUNT = 35;
let currentLang = 'zh';
let answers = [];
let quizQuestions = [];
let currentQuestionIndex = 0;
let startTime = 0;
let currentResult = null;

const allQuestions = [
    {
        type: "entryFragger",
        text: {
            zh: "开局时，我喜欢第一个冲进敌方区域",
            en: "I like to be the first one to push into enemy territory",
            zh_tw: "開局時，我喜歡第一個衝進敵方區域"
        }
    },
    {
        type: "entryFragger",
        text: {
            zh: "即使人数处于劣势，我也会主动发起进攻",
            en: "I'll initiate fights even when outnumbered",
            zh_tw: "即使人數處於劣勢，我也會主動發起進攻"
        }
    },
    {
        type: "entryFragger",
        text: {
            zh: "我擅长使用步枪进行近距离交火",
            en: "I'm good at close-range rifle fights",
            zh_tw: "我擅長使用步槍進行近距離交火"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我更喜欢使用AWP进行远距离狙击",
            en: "I prefer using AWP for long-range sniping",
            zh_tw: "我更喜歡使用AWP進行遠距離狙擊"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我能耐心等待最佳射击时机",
            en: "I can patiently wait for the perfect shot",
            zh_tw: "我能耐心等待最佳射擊時機"
        }
    },
    {
        type: "awper",
        text: {
            zh: "我擅长在关键位置卡点防守",
            en: "I'm good at holding angles defensively",
            zh_tw: "我擅長在關鍵位置卡點防守"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我经常指挥队友执行战术",
            en: "I often call strategies for my team",
            zh_tw: "我經常指揮隊友執行戰術"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我会根据局势灵活调整战术",
            en: "I adapt strategies based on the situation",
            zh_tw: "我會根據局勢靈活調整戰術"
        }
    },
    {
        type: "igl",
        text: {
            zh: "我善于分析敌方的战术意图",
            en: "I'm good at reading enemy tactics",
            zh_tw: "我善於分析敵方的戰術意圖"
        }
    },
    {
        type: "support",
        text: {
            zh: "我愿意为队友提供火力支援",
            en: "I'm willing to provide fire support for teammates",
            zh_tw: "我願意為隊友提供火力支援"
        }
    },
    {
        type: "support",
        text: {
            zh: "我擅长使用道具为团队创造优势",
            en: "I'm good at using utilities to create advantages",
            zh_tw: "我擅長使用道具為團隊創造優勢"
        }
    },
    {
        type: "support",
        text: {
            zh: "保护队友是我的首要任务",
            en: "Protecting teammates is my priority",
            zh_tw: "保護隊友是我的首要任務"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "我喜欢单独行动，寻找机会偷袭敌人",
            en: "I prefer solo play, looking for flanking opportunities",
            zh_tw: "我喜歡單獨行動，尋找機會偷襲敵人"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "我善于隐藏自己的位置",
            en: "I'm good at staying hidden",
            zh_tw: "我善於隱藏自己的位置"
        }
    },
    {
        type: "lurker",
        text: {
            zh: "残局时我能发挥最大作用",
            en: "I perform best in 1vX situations",
            zh_tw: "殘局時我能發揮最大作用"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "我喜欢在角落埋伏等待敌人",
            en: "I enjoy camping in corners waiting for enemies",
            zh_tw: "我喜歡在角落埋伏等待敵人"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "我会利用地图优势卡点阴人",
            en: "I use map advantages to ambush enemies",
            zh_tw: "我會利用地圖優勢卡點陰人"
        }
    },
    {
        type: "laoliu",
        text: {
            zh: "耐心是我的优点，我能等很久",
            en: "Patience is my strong suit, I can wait a long time",
            zh_tw: "耐心是我的優點，我能等很久"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "我喜欢无脑冲锋，不怕牺牲",
            en: "I like rushing in without fear",
            zh_tw: "我喜歡無腦衝鋒，不怕犧牲"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "我相信个人能力可以战胜一切",
            en: "I believe individual skill can overcome anything",
            zh_tw: "我相信個人能力可以戰勝一切"
        }
    },
    {
        type: "reckless",
        text: {
            zh: "即使队友阵亡，我也会继续推进",
            en: "I keep pushing even when teammates die",
            zh_tw: "即使隊友陣亡，我也會繼續推進"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "我喜欢在语音里指挥和交流",
            en: "I like to call out and communicate aggressively",
            zh_tw: "我喜歡在語音裡指揮和交流"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "输了比赛我会感到很沮丧",
            en: "I get frustrated when losing",
            zh_tw: "輸了比賽我會感到很沮喪"
        }
    },
    {
        type: "toxic",
        text: {
            zh: "我对队友的表现有较高要求",
            en: "I have high expectations for teammates",
            zh_tw: "我對隊友的表現有較高要求"
        }
    },
    {
        type: "casual",
        text: {
            zh: "输赢对我来说不是最重要的",
            en: "Winning isn't the most important thing to me",
            zh_tw: "輸贏對我來說不是最重要的"
        }
    },
    {
        type: "casual",
        text: {
            zh: "我喜欢和队友聊天交流",
            en: "I enjoy chatting with teammates",
            zh_tw: "我喜歡和隊友聊天交流"
        }
    },
    {
        type: "casual",
        text: {
            zh: "游戏只是我的娱乐方式",
            en: "Gaming is just for fun for me",
            zh_tw: "遊戲只是我的娛樂方式"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我很在意武器皮肤的外观",
            en: "I care about weapon skin aesthetics",
            zh_tw: "我很在意武器皮膚的外觀"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我收集了很多稀有皮肤",
            en: "I have a collection of rare skins",
            zh_tw: "我收集了很多稀有皮膚"
        }
    },
    {
        type: "skinCollector",
        text: {
            zh: "我会根据皮肤选择使用的武器",
            en: "I choose weapons based on their skins",
            zh_tw: "我會根據皮膚選擇使用的武器"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "面对残局，我能保持冷静",
            en: "I stay calm in clutch situations",
            zh_tw: "面對殘局，我能保持冷靜"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "我擅长处理1vN的情况",
            en: "I'm good at 1vN situations",
            zh_tw: "我擅長處理1vN的情況"
        }
    },
    {
        type: "clutchGod",
        text: {
            zh: "压力越大，我的发挥越好",
            en: "I perform better under pressure",
            zh_tw: "壓力越大，我的發揮越好"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我擅长与敌人进行互换",
            en: "I'm good at trading kills",
            zh_tw: "我擅長與敵人進行互換"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我总是确保自己的死亡有价值",
            en: "I always make sure my death counts",
            zh_tw: "我總是確保自己的死亡有價值"
        }
    },
    {
        type: "tradeFragger",
        text: {
            zh: "我注重团队整体的击杀效率",
            en: "I focus on team kill efficiency",
            zh_tw: "我注重團隊整體的擊殺效率"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "如果比分落后太多，我会想早点结束",
            en: "If we're too far behind, I want to surrender",
            zh_tw: "如果比分落後太多，我會想早點結束"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "逆风局会影响我的心态",
            en: "Losing streaks affect my mood",
            zh_tw: "逆風局會影響我的心態"
        }
    },
    {
        type: "quitter",
        text: {
            zh: "我不太能接受连败",
            en: "I don't handle losing streaks well",
            zh_tw: "我不太能接受連敗"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我更喜欢专注游戏，少说话",
            en: "I prefer focusing on the game and staying quiet",
            zh_tw: "我更喜歡專注遊戲，少說話"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我相信用实力说话",
            en: "I believe actions speak louder than words",
            zh_tw: "我相信用實力說話"
        }
    },
    {
        type: "silent",
        text: {
            zh: "我很少在语音里说话",
            en: "I rarely talk in voice chat",
            zh_tw: "我很少在語音裡說話"
        }
    },
    {
        type: "all",
        text: {
            zh: "我能适应各种游戏角色",
            en: "I can adapt to any role",
            zh_tw: "我能適應各種遊戲角色"
        }
    },
    {
        type: "all",
        text: {
            zh: "我擅长多种武器和战术",
            en: "I'm good with various weapons and tactics",
            zh_tw: "我擅長多種武器和戰術"
        }
    },
    {
        type: "all",
        text: {
            zh: "我可以根据团队需要改变风格",
            en: "I can change my playstyle based on team needs",
            zh_tw: "我可以根據團隊需要改變風格"
        }
    }
];

function generateQuestions() {
    const shuffled = [...allQuestions].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, QUESTIONS_COUNT);
}

function initQuiz() {
    quizQuestions = generateQuestions();
    answers = new Array(quizQuestions.length).fill(0);
    currentQuestionIndex = 0;
    startTime = Date.now();
    
    const container = document.getElementById('questions');
    container.innerHTML = '';
    
    quizQuestions.forEach((q, i) => {
        const qEl = document.createElement('div');
        qEl.className = 'question';
        qEl.style.display = i === 0 ? 'block' : 'none';
        
        qEl.innerHTML = `
            <div class="question-number">${i + 1}/${quizQuestions.length}</div>
            <div class="question-text">${q.text[currentLang]}</div>
            <div class="options">
                ${lang[currentLang].options.map((opt, j) => `
                    <button class="option" data-qidx="${i}" data-optidx="${j}" data-type="${q.type}" data-score="${j + 1}">
                        ${opt}
                    </button>
                `).join('')}
            </div>
        `;
        container.appendChild(qEl);
    });
    
    document.querySelectorAll('.option').forEach(opt => {
        opt.addEventListener('click', function() {
            const qIdx = parseInt(this.dataset.qidx);
            const optIdx = parseInt(this.dataset.optidx);
            const type = this.dataset.type;
            const score = parseInt(this.dataset.score);
            selectAnswer(qIdx, optIdx, type, score);
        });
    });
    
    document.getElementById('total').textContent = quizQuestions.length;
    document.getElementById('answered').textContent = 0;
    document.getElementById('progress-percent').textContent = '0%';
    document.getElementById('progress').style.width = '0%';
    document.getElementById('submit').disabled = true;
}

function selectAnswer(qIdx, optIdx, type, score) {
    answers[qIdx] = { type, score };
    
    const qEl = document.querySelector(`.question:nth-child(${qIdx + 1})`);
    qEl.style.display = 'none';
    
    if (qIdx < quizQuestions.length - 1) {
        const nextEl = document.querySelector(`.question:nth-child(${qIdx + 2})`);
        nextEl.style.display = 'block';
        currentQuestionIndex = qIdx + 1;
    }
    
    updateProgress();
    
    if (answers.filter(a => a !== 0).length === quizQuestions.length) {
        document.getElementById('submit').disabled = false;
        document.getElementById('submit').textContent = lang[currentLang].viewResult;
    }
}

function updateProgress() {
    const answered = answers.filter(a => a !== 0).length;
    const totalQuestions = quizQuestions.length;
    const percent = Math.round((answered / totalQuestions) * 100);
    
    const answeredEl = document.getElementById('answered');
    if (answeredEl) answeredEl.textContent = answered;
    
    const totalEl = document.getElementById('total');
    if (totalEl) totalEl.textContent = totalQuestions;
    
    const progressEl = document.getElementById('progress');
    if (progressEl) progressEl.style.width = percent + '%';
    
    const progressPercentEl = document.getElementById('progress-percent');
    if (progressPercentEl) progressPercentEl.textContent = percent + '%';
    
    const submitBtn = document.getElementById('submit');
    if (submitBtn) {
        submitBtn.disabled = answered < totalQuestions;
        if (answered === totalQuestions) {
            submitBtn.textContent = lang[currentLang].viewResult;
        }
    }
}

function calculateScores() {
    const scores = {};
    Object.keys(types).forEach(type => {
        scores[type] = 0;
    });
    
    answers.forEach(answer => {
        if (answer !== 0) {
            scores[answer.type] += answer.score;
        }
    });
    
    return scores;
}

function calculateRank(scores, personalityType) {
    const eliteTypes = ['awper', 'clutchGod', 'entryFragger', 'igl', 'skinCollector', 'support', 'tradeFragger'];
    const maxRankIndex = eliteTypes.includes(personalityType) ? lang[currentLang].ranks.length - 1 : 4;
    
    const total = Object.values(scores).reduce((a, b) => a + b, 0);
    const avg = total / answers.length;
    
    let rankIndex = Math.floor((avg - 1) * (maxRankIndex + 1) / 4);
    rankIndex = Math.max(0, Math.min(maxRankIndex, rankIndex));
    
    return lang[currentLang].ranks[rankIndex];
}

function matchPersonality(scores) {
    let maxScore = 0;
    let matchedType = 'all';
    
    Object.keys(scores).forEach(type => {
        if (scores[type] > maxScore) {
            maxScore = scores[type];
            matchedType = type;
        }
    });
    
    return { type: matchedType, score: maxScore };
}

const proPlayerImageExtensions = ['webp', 'png', 'jpg', 'jpeg', 'gif'];

function loadShareProPlayer(playerName, playerDesc) {
    const knownPlayerNames = [
        'donk', 'kennyS', 'sh1ro', 'm0NESY', 'ropz', 'NiKo',
        'apEX', 'Magisk', 'Spinx', 'bLitz', 'flameZ', 'Brollan',
        'xertioN', 'torzsi', 'Jimpphat', 'Senzu', 'mzinho', '910I',
        'Techno4K', 'kyxsan', 'TeSeS', 'kyousuke', 'magixx', 'zont1x',
        'chopper', 's1mple', 'mezii', 'ZywOo'
    ];
    
    let imageFileName = playerName;
    if (!knownPlayerNames.includes(playerName)) {
        imageFileName = playerName.toLowerCase().replace(/[^a-z0-9]/g, '');
    }
    
    const paths = proPlayerImageExtensions.map(ext => `https://21cc.oss-cn-hongkong.aliyuncs.com/zywj/image/juese/${imageFileName}.${ext}`);
    
    function tryLoad(index) {
        if (index >= paths.length) {
            document.getElementById('share-pro-content').innerHTML = `
                <div class="share-pro-item">
                    <div class="share-pro-image">
                        <div class="share-pro-placeholder">${playerName.charAt(0)}</div>
                    </div>
                    <div class="share-pro-info">
                        <div class="share-pro-name">${playerName}</div>
                        <div class="share-pro-desc">${playerDesc}</div>
                    </div>
                </div>
            `;
            return;
        }
        
        const img = new Image();
        img.onload = function() {
            document.getElementById('share-pro-content').innerHTML = `
                <div class="share-pro-item">
                    <div class="share-pro-image">
                        <img src="${paths[index]}" alt="${playerName}">
                    </div>
                    <div class="share-pro-info">
                        <div class="share-pro-name">${playerName}</div>
                        <div class="share-pro-desc">${playerDesc}</div>
                    </div>
                </div>
            `;
        };
        img.onerror = function() {
            tryLoad(index + 1);
        };
        img.src = paths[index];
    }
    
    tryLoad(0);
}

function loadProPlayerImage(playerName, playerDesc, containerId = 'pro-player-content') {
    const knownPlayerNames = [
        'donk', 'kennyS', 'sh1ro', 'm0NESY', 'ropz', 'NiKo',
        'apEX', 'Magisk', 'Spinx', 'bLitz', 'flameZ', 'Brollan',
        'xertioN', 'torzsi', 'Jimpphat', 'Senzu', 'mzinho', '910I',
        'Techno4K', 'kyxsan', 'TeSeS', 'kyousuke', 'magixx', 'zont1x',
        'chopper', 's1mple', 'mezii', 'ZywOo'
    ];
    
    let imageFileName = playerName;
    if (!knownPlayerNames.includes(playerName)) {
        imageFileName = playerName.toLowerCase().replace(/[^a-z0-9]/g, '');
    }
    
    const paths = proPlayerImageExtensions.map(ext => `https://21cc.oss-cn-hongkong.aliyuncs.com/zywj/image/juese/${imageFileName}.${ext}`);
    const baseName = playerName.toLowerCase().replace(/[^a-z0-9]/g, '');
    const playerData = proPlayers[baseName] || null;
    
    console.log('Loading pro player:', playerName, 'imageFileName:', imageFileName, 'playerData:', playerData);
    
    function renderPlayer(imageSrc, isPlaceholder = false) {
        const statsHtml = playerData?.stats ? `
            <div class="pro-player-stats">
                <div class="pro-player-stat">
                    <div class="pro-player-stat-value">${playerData.stats.rating}</div>
                    <div class="pro-player-stat-label">Rating</div>
                </div>
                <div class="pro-player-stat">
                    <div class="pro-player-stat-value">${playerData.stats.kdRatio}</div>
                    <div class="pro-player-stat-label">K/D</div>
                </div>
                <div class="pro-player-stat">
                    <div class="pro-player-stat-value">${playerData.stats.headshotPercent}%</div>
                    <div class="pro-player-stat-label">HS%</div>
                </div>
            </div>
        ` : '';
        
        const achievementsHtml = playerData?.achievements && playerData.achievements.length > 0 ? `
            <div class="pro-player-achievements">
                <div class="pro-player-achievements-title">🏆 主要成就</div>
                <div class="pro-player-achievement-list">
                    ${playerData.achievements.slice(0, 3).map(achievement => `
                        <span class="pro-player-achievement">${achievement}</span>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        const metaHtml = playerData ? `
            <div class="pro-player-meta">
                <span class="pro-player-meta-item">🏠 ${playerData.team}</span>
                <span class="pro-player-meta-item">🎯 ${playerData.role}</span>
                <span class="pro-player-meta-item">🌍 ${playerData.country}</span>
            </div>
        ` : '';
        
        const imageHtml = isPlaceholder ? `
            <div class="pro-player-image">
                <div class="pro-player-placeholder">${playerName.charAt(0)}</div>
            </div>
        ` : `
            <div class="pro-player-image">
                <img src="${imageSrc}" alt="${playerName}" loading="lazy">
            </div>
        `;
        
        const html = `
            <div class="pro-player-item">
                <div class="pro-player-top-bar"></div>
                <div class="pro-player-content-wrapper">
                    <div class="pro-player-main-row">
                        <div class="pro-player-image-wrapper">
                            ${imageHtml}
                            <div class="pro-player-badge">PRO</div>
                        </div>
                        <div class="pro-player-info">
                            <div class="pro-player-header">
                                <div class="pro-player-name">${playerName}</div>
                                ${playerData ? `<div class="pro-player-real-name">${playerData.realName}</div>` : ''}
                            </div>
                            ${metaHtml}
                            <div class="pro-player-desc">${playerDesc}</div>
                        </div>
                    </div>
                    <div class="pro-player-divider"></div>
                    ${statsHtml}
                    ${achievementsHtml}
                </div>
            </div>
        `;
        
        console.log('Rendering pro player HTML:', html);
        document.getElementById(containerId).innerHTML = html;
    }
    
    function tryLoad(index) {
        if (index >= paths.length) {
            console.log('No image found, using placeholder');
            renderPlayer(null, true);
            return;
        }
        
        const img = new Image();
        img.onload = function() {
            console.log('Image loaded:', paths[index]);
            renderPlayer(paths[index], false);
        };
        img.onerror = function() {
            console.log('Image load failed:', paths[index], 'trying next...');
            tryLoad(index + 1);
        };
        img.src = paths[index];
    }
    
    tryLoad(0);
}

function showResult() {
    const scores = calculateScores();
    const matched = matchPersonality(scores);
    const rank = calculateRank(scores, matched.type);
    const endTime = Date.now();
    const duration = Math.round((endTime - startTime) / 1000);
    const speed = duration < 120 ? lang[currentLang] === 'en' ? 'Fast' : '快速' : duration < 180 ? lang[currentLang] === 'en' ? 'Normal' : '正常' : lang[currentLang] === 'en' ? 'Slow' : '较慢';
    
    const t = types[matched.type];
    const typeName = typeof t.name === 'object' ? t.name[currentLang] : t.name;
    const typeDesc = typeof t.desc === 'object' ? t.desc[currentLang] : t.desc;
    const imageName = imageNames[matched.type] || 'awper.png';
    
    currentResult = {
        personalityType: matched.type,
        match: Math.round((matched.score / (answers.length * 5)) * 100),
        rank: rank,
        speed: speed,
        duration: duration,
        imagePath: `https://21cc.oss-cn-hongkong.aliyuncs.com/zywj/image/${imageName}`,
        typeName: typeName,
        typeDesc: typeDesc,
        scores: scores
    };
    
    document.getElementById('result-type').textContent = typeName;
    document.getElementById('result-match').textContent = lang[currentLang].match + ' ' + currentResult.match + (currentLang === 'en' ? '%' : '分');
    document.getElementById('stat-accuracy').textContent = currentResult.match + (currentLang === 'en' ? '%' : '分');
    document.getElementById('stat-speed').textContent = speed;
    
    renderRankHex(rank);
    
    document.getElementById('result-desc-text').innerHTML = typeDesc.replace(/\n/g, '<br>');
    document.getElementById('result-image').innerHTML = `<img src="${currentResult.imagePath}" alt="${typeName}" style="width: 100%; height: 100%; object-fit: cover;">`;
    
    playResultSound();
    addResultEffects();
    
    document.getElementById('encouragement-text').textContent = lang[currentLang].encouragementText[matched.type] || '';
    
    const proPlayer = t.player;
    const playerDesc = typeof t.playerDesc === 'object' ? t.playerDesc[currentLang] : t.playerDesc;
    
    console.log('showResult - matched type:', matched.type);
    console.log('showResult - proPlayer:', proPlayer);
    console.log('showResult - playerDesc:', playerDesc);
    
    loadProPlayerImage(proPlayer, playerDesc);
    
    const dimGrid = document.getElementById('dimensions-grid');
    dimGrid.innerHTML = '';
    
    Object.keys(scores).forEach(type => {
        const dimType = types[type];
        const dimName = typeof dimType.name === 'object' ? dimType.name[currentLang] : dimType.name;
        const dimScore = Math.round((scores[type] / (answers.length * 5 / 15)) * 100);
        
        const dimEl = document.createElement('div');
        dimEl.className = 'dim-item';
        dimEl.innerHTML = `
            <div class="dim-header">
                <div class="dim-name">${dimName}</div>
                <div class="dim-score">${dimScore}${currentLang === 'en' ? '%' : '分'}</div>
            </div>
            <div class="dim-bar-container">
                <div class="dim-bar" style="width: ${dimScore}%"></div>
            </div>
        `;
        dimGrid.appendChild(dimEl);
    });
    
    document.getElementById('quiz-page').style.display = 'none';
    document.getElementById('result-page').style.display = 'flex';
}

function startTest() {
    document.getElementById('home-page').style.display = 'none';
    document.getElementById('quiz-page').style.display = 'block';
    initQuiz();
}

function restart() {
    document.getElementById('result-page').style.display = 'none';
    document.getElementById('quiz-page').style.display = 'block';
    initQuiz();
}

function goHome() {
    document.getElementById('result-page').style.display = 'none';
    document.getElementById('share-modal').style.display = 'none';
    document.getElementById('home-page').style.display = 'flex';
}

function openShareModal() {
    if (!currentResult) return;
    
    const t = types[currentResult.personalityType];
    const typeName = typeof t.name === 'object' ? t.name[currentLang] : t.name;
    const typeDesc = typeof t.desc === 'object' ? t.desc[currentLang] : t.desc;
    const playerName = t.player;
    const playerDesc = typeof t.playerDesc === 'object' ? t.playerDesc[currentLang] : t.playerDesc;
    
    document.getElementById('share-title').textContent = lang[currentLang].shareTitle;
    document.getElementById('share-type').textContent = typeName;
    document.getElementById('share-match').textContent = lang[currentLang].match + ' ' + currentResult.match + (currentLang === 'en' ? '%' : '分') + ' · ' + lang[currentLang].rank + ' ' + currentResult.rank;
    document.getElementById('share-desc').innerHTML = typeDesc.substring(0, 120).replace(/\n/g, ' ') + '...';
    
    document.getElementById('share-pro-title').textContent = lang[currentLang].proMatch;
    loadShareProPlayer(playerName, playerDesc);
    
    document.getElementById('scan-text').textContent = lang[currentLang].scanText;
    document.getElementById('copy-link-text').textContent = lang[currentLang].copyLinkText;
    
    document.getElementById('share-image').innerHTML = `<img src="${currentResult.imagePath}" alt="${typeName}" style="width: 100%; height: 100%; object-fit: cover;">`;
    
    generateQRCode();
    document.getElementById('share-modal').style.display = 'flex';
}

function closeShareModal() {
    document.getElementById('share-modal').style.display = 'none';
}

function generateQRCode() {
    const url = window.location.href;
    const qrcodeContainer = document.getElementById('qrcode');
    
    try {
        const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(url)}`;
        qrcodeContainer.innerHTML = `<img src="${apiUrl}" alt="QR Code" style="width: 150px; height: 150px;">`;
    } catch (error) {
        qrcodeContainer.innerHTML = `<p style="color: red;">${lang[currentLang].qrError || 'Failed to generate QR Code'}</p>`;
    }
}

function copyShareLink() {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        const successEl = document.getElementById('copy-success');
        successEl.textContent = lang[currentLang].copySuccess;
        successEl.style.display = 'block';
        setTimeout(() => {
            successEl.style.display = 'none';
        }, 2000);
    });
}

function setLanguage(langCode) {
    currentLang = langCode;
    
    document.getElementById('title').textContent = lang[langCode].title;
    document.getElementById('subtitle').textContent = lang[langCode].subtitle;
    document.getElementById('description').textContent = lang[langCode].description;
    document.getElementById('feature1').textContent = lang[langCode].feature1;
    document.getElementById('feature2').textContent = lang[langCode].feature2;
    document.getElementById('feature3').textContent = lang[langCode].feature3;
    document.getElementById('start-btn').textContent = lang[langCode].startBtn;
    
    const introTitlePersonality = document.getElementById('intro-title-personality');
    const introTitleProplayers = document.getElementById('intro-title-proplayers');
    const introTitleRanks = document.getElementById('intro-title-ranks');
    
    if (introTitlePersonality) introTitlePersonality.textContent = lang[langCode].intro.personality;
    if (introTitleProplayers) introTitleProplayers.textContent = lang[langCode].intro.proplayers;
    if (introTitleRanks) introTitleRanks.textContent = lang[langCode].intro.ranks;
    
    document.querySelectorAll('[data-key^="personality_"]').forEach(el => {
        const key = el.dataset.key.replace('personality_', '');
        el.textContent = lang[langCode].personalities[key] || el.textContent;
    });
    
    document.querySelectorAll('[data-key="rank_s"]').forEach(el => {
        el.textContent = lang[langCode].intro.rank_s;
    });
    
    if (document.getElementById('quiz-page').style.display === 'block') {
        document.getElementById('quiz-title').textContent = lang[langCode].quizTitle;
        document.getElementById('submit').textContent = answers.filter(a => a !== 0).length === quizQuestions.length ? lang[langCode].viewResult : lang[langCode].submitBtn;
        
        document.querySelectorAll('.question').forEach((q, i) => {
            const questionText = quizQuestions[i]?.text?.[langCode];
            if (questionText) {
                const qTextEl = q.querySelector('.question-text');
                if (qTextEl) qTextEl.textContent = questionText;
            }
            
            q.querySelectorAll('.option').forEach((opt, j) => {
                opt.textContent = lang[langCode].options[j];
            });
        });
    }
    
    if (document.getElementById('result-page').style.display === 'flex') {
        document.getElementById('stat-label-accuracy').textContent = lang[langCode].match;
        document.getElementById('stat-label-speed').textContent = lang[langCode].speed;
        document.getElementById('stat-label-rank').textContent = lang[langCode].rank;
        document.getElementById('result-personality').textContent = lang[langCode].personality;
        document.getElementById('result-dimensions-title').textContent = lang[langCode].dimensionsTitle;
        document.getElementById('result-pro-match').textContent = lang[langCode].proMatch;
        document.getElementById('result-encouragement').textContent = lang[langCode].encouragement;
        document.getElementById('result-restart').textContent = lang[langCode].restartBtn;
        document.getElementById('result-share').textContent = lang[langCode].shareBtn;
        document.getElementById('result-home').textContent = lang[langCode].homeBtn;
        document.getElementById('copy-success').textContent = lang[langCode].copySuccess;
        
        if (currentResult) {
            const t = types[currentResult.personalityType];
            document.getElementById('result-type').textContent = typeof t.name === 'object' ? t.name[langCode] : t.name;
            document.getElementById('result-match').textContent = lang[langCode].match + ' ' + currentResult.match + (langCode === 'en' ? '%' : '分');
            document.getElementById('result-desc-text').innerHTML = (typeof t.desc === 'object' ? t.desc[langCode] : t.desc).replace(/\n/g, '<br>');
            document.getElementById('encouragement-text').textContent = lang[langCode].encouragementText[currentResult.personalityType] || '';
            
            const playerDesc = typeof t.playerDesc === 'object' ? t.playerDesc[langCode] : t.playerDesc;
            loadProPlayerImage(t.player, playerDesc);
            
            const dimGrid = document.getElementById('dimensions-grid');
            dimGrid.innerHTML = '';
            Object.keys(currentResult.scores).forEach(type => {
                const dimType = types[type];
                const dimName = typeof dimType.name === 'object' ? dimType.name[langCode] : dimType.name;
                const dimScore = Math.round((currentResult.scores[type] / (answers.length * 5 / 15)) * 100);
                
                const dimEl = document.createElement('div');
                dimEl.className = 'dim-item';
                dimEl.innerHTML = `
                    <div class="dim-header">
                        <div class="dim-name">${dimName}</div>
                        <div class="dim-score">${dimScore}${langCode === 'en' ? '%' : '分'}</div>
                    </div>
                    <div class="dim-bar-container">
                        <div class="dim-bar" style="width: ${dimScore}%"></div>
                    </div>
                `;
                dimGrid.appendChild(dimEl);
            });
        }
    }
    
    const shareModal = document.getElementById('share-modal');
    if (shareModal.style.display === 'flex') {
        document.getElementById('share-title').textContent = lang[langCode].shareTitle;
        document.getElementById('scan-text').textContent = lang[langCode].scanText;
        document.getElementById('copy-link-text').textContent = lang[langCode].copyLinkText;
        
        if (currentResult) {
            const t = types[currentResult.personalityType];
            const typeName = typeof t.name === 'object' ? t.name[langCode] : t.name;
            const typeDesc = typeof t.desc === 'object' ? t.desc[langCode] : t.desc;
            
            document.getElementById('share-type').textContent = typeName;
            document.getElementById('share-match').textContent = lang[langCode].match + ' ' + currentResult.match + (langCode === 'en' ? '%' : '分') + ' · ' + lang[langCode].rank + ' ' + currentResult.rank;
            document.getElementById('share-desc').innerHTML = typeDesc.substring(0, 150).replace(/\n/g, ' ') + '...';
        }
    }
}

function renderRankHex(rank) {
    const hexContainer = document.getElementById('stat-rank');
    if (!hexContainer) return;
    
    const rankConfig = {
        'D': { class: 'rank-hex', text: 'D' },
        'D+': { class: 'rank-hex rank-hex-plus', text: 'D+' },
        'C': { class: 'rank-hex', text: 'C' },
        'C+': { class: 'rank-hex rank-hex-plus', text: 'C+' },
        'B': { class: 'rank-hex', text: 'B' },
        'B+': { class: 'rank-hex rank-hex-plus', text: 'B+' },
        'A': { class: 'rank-hex rank-hex-a', text: 'A' },
        'A+': { class: 'rank-hex rank-hex-plus rank-hex-a', text: 'A+' },
        'S': { class: 'rank-hex-s', text: 'S' }
    };
    
    const config = rankConfig[rank] || rankConfig['D'];
    hexContainer.innerHTML = `<div class="${config.class} result-hex">${config.text}</div>`;
    
    setTimeout(() => {
        const hex = hexContainer.querySelector('.result-hex');
        if (hex) hex.classList.add('hex-reveal');
    }, 100);
}

function playResultSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1);
        oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch(e) {
        console.log('Audio not supported');
    }
}

function addResultEffects() {
    const resultPage = document.getElementById('result-page');
    const resultImage = document.getElementById('result-image');
    
    if (resultPage) {
        resultPage.classList.add('result-reveal');
    }
    
    if (resultImage) {
        resultImage.classList.add('image-glow');
        setTimeout(() => resultImage.classList.remove('image-glow'), 2000);
    }
    
    createParticles();
}

function createParticles() {
    const container = document.querySelector('.result-content');
    if (!container) return;
    
    for (let i = 0; i < 15; i++) {
        setTimeout(() => {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 2 + 's';
            particle.style.setProperty('--particle-color', ['#4ade80', '#22c55e', '#86efac'][Math.floor(Math.random() * 3)]);
            container.appendChild(particle);
            
            setTimeout(() => particle.remove(), 3000);
        }, i * 100);
    }
}